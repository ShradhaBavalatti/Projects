# 🔧 FixWise - AI-Powered Log Analyzer

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.8%2B-green)
![License](https://img.shields.io/badge/license-MIT-green)

## 📋 Table of Contents

- [What is FixWise?](#what-is-fixwise)
- [Why Do You Need It?](#why-do-you-need-it)
- [Features](#features)
- [Quick Start](#quick-start)
- [Installation Guide](#installation-guide)
- [How to Use](#how-to-use)
- [Understanding the Results](#understanding-the-results)
- [Troubleshooting](#troubleshooting)
- [Project Structure](#project-structure)
- [FAQ](#faq)
- [Support](#support)

---

## 🤔 What is FixWise?

**FixWise** is a simple web application that helps you find and fix problems in your software logs. Think of it as a "doctor for your logs" - it reads your error logs and tells you what went wrong and how to fix it.

### In Simple Terms:
- **Logs**: Text files that record everything your application does
- **Problems**: When something goes wrong, it gets written to these log files
- **FixWise**: Reads these logs and tells you what the problem is and how to solve it

### Why Not Just Read Logs Manually?
Logs can have thousands or millions of lines! Finding the actual problem is like finding a needle in a haystack. FixWise does this automatically for you.

---

## ⚡ Why Do You Need It?

### Real-World Scenario:
Your application crashes, and you get a log file with 50,000 lines of text. You need to:
1. Find what went wrong
2. Understand why it happened
3. Know how to fix it

**Without FixWise**: You manually read through thousands of lines 😫
**With FixWise**: Upload the file, get analysis in seconds ✨

### Common Problems FixWise Detects:
- **Database Issues**: When your app can't talk to the database
- **Authentication Errors**: When login/permission problems occur
- **Timeouts**: When things take too long to respond
- **Memory Issues**: When the app runs out of memory
- **General Application Errors**: When code breaks

---

## ✨ Features

### 🎯 Core Features
| Feature | Description |
|---------|-------------|
| **File Upload** | Upload .log or .txt files (up to 100 MB) |
| **Automatic Analysis** | AI analyzes your logs automatically |
| **Root Cause Detection** | Identifies what went wrong |
| **Solutions Provided** | Gets step-by-step fixes |
| **Severity Levels** | Shows how serious the problem is |
| **Confidence Score** | Shows how confident the analysis is |
| **Log Viewer** | Read the full log in the browser |
| **User-Friendly Interface** | Beautiful, easy-to-use design |

### 🔒 Security Features
- Files are stored securely on your server
- No data sent to external services
- Maximum file size limits
- Secure file handling

---

## 🚀 Quick Start (5 Minutes)

### For Windows Users:

**Step 1:** Install Python
- Go to [python.org](https://www.python.org/downloads/)
- Download Python 3.8 or newer
- Run installer and check "Add Python to PATH"

**Step 2:** Open Command Prompt
- Press `Windows Key + R`
- Type `cmd` and press Enter

**Step 3:** Run FixWise
```bash
cd C:\Users\YourUsername\Desktop\Projects\FixWise
py -m pip install -r requirements.txt
py app.py
```

**Step 4:** Open Browser
- Visit: `http://127.0.0.1:5000`
- You should see the FixWise interface

---

### For Mac/Linux Users:

**Step 1:** Open Terminal

**Step 2:** Navigate to the folder
```bash
cd /path/to/FixWise
```

**Step 3:** Install and run
```bash
python3 -m pip install -r requirements.txt
python3 app.py
```

**Step 4:** Open Browser
- Visit: `http://127.0.0.1:5000`

---

## 📦 Installation Guide

### What You Need:
- **Python 3.8 or newer** (a programming language)
- **pip** (a tool to install Python packages - comes with Python)
- **Modern web browser** (Chrome, Firefox, Safari, Edge)
- **10 minutes of time**

### Step-by-Step Installation:

#### 1️⃣ **Install Python**
- **Windows**: [Download from python.org](https://www.python.org/downloads/)
  - Run the installer
  - ✅ Check the box: "Add Python to PATH"
  - Click "Install Now"

- **Mac**: Open Terminal and run:
  ```bash
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  brew install python3
  ```

- **Linux**: Open Terminal and run:
  ```bash
  sudo apt-get update
  sudo apt-get install python3 python3-pip
  ```

#### 2️⃣ **Download FixWise** (if not already done)
- Clone or download the project files to your computer

#### 3️⃣ **Install Dependencies**
Open Command Prompt/Terminal in the FixWise folder and run:
```bash
pip install -r requirements.txt
```

**What this does**: Downloads all the tools FixWise needs to work

#### 4️⃣ **Verify Installation**
Run:
```bash
python -m pip list
```

You should see `flask`, `flask-cors`, and other packages listed.

#### 5️⃣ **Start the Application**
```bash
python app.py
```

You should see:
```
🚀 Starting FixWise Flask Server...
📍 Visit: http://127.0.0.1:5000
🛑 Press CTRL+C to stop
```

---

## 💻 How to Use

### Basic Usage (5 Steps):

#### **Step 1: Start the Application**
```bash
python app.py
```

#### **Step 2: Open Your Browser**
- Type in address bar: `http://127.0.0.1:5000`
- Press Enter
- You'll see the FixWise home page

#### **Step 3: Upload Your Log File**
**Option A - Click the Browse Button:**
- Click "Browse Files" button
- Select your .log or .txt file
- Click "Open"

**Option B - Drag and Drop:**
- Drag your log file
- Drop it on the upload area

#### **Step 4: Wait for Analysis**
- A loading spinner will appear
- FixWise analyzes your log
- Usually takes 1-5 seconds

#### **Step 5: Review Results**
You'll see:
- **Root Cause**: What went wrong
- **Severity Level**: How serious (Critical/Warning/Info)
- **Confidence Score**: How sure FixWise is (0-100%)
- **Error Details**: Specific problems found
- **Recommended Solutions**: How to fix it

---

### Advanced Features:

#### **View Full Log Content**
- Click the "Log Content" tab
- See the entire log file in your browser
- Useful for cross-referencing

#### **Download Results**
- Right-click on the analysis results
- Select "Save as" to save to your computer

#### **Analyze Multiple Files**
- Click "Back" button
- Upload another log file
- Repeat!

---

## 📊 Understanding the Results

### What Each Section Means:

#### **1. Root Cause** 🎯
The main problem detected in your logs

**Examples:**
- "Database Connection Failed" → Your app can't talk to the database
- "Authentication Error" → Login or permission problem
- "Memory Exhaustion" → App ran out of memory
- "Request Timeout" → Something took too long to respond

#### **2. Severity Badge**
How serious is this problem?

| Badge | Meaning | Action |
|-------|---------|--------|
| 🔴 CRITICAL | Very serious! Fix immediately | Fix ASAP |
| 🟠 WARNING | Important issue | Fix soon |
| 🔵 INFO | Minor issue | Monitor |

#### **3. Confidence Score** 📊
How sure is FixWise about this analysis?

- **90%+**: Very confident, this is likely correct
- **70-89%**: Fairly confident
- **Below 70%**: Take with a grain of salt

#### **4. Error Details** ⚠️
The specific problems found

**Example:**
```
Error: Database server is unreachable or not responding
Error: Connection timeout occurred
Error: Authentication credentials are invalid
```

#### **5. Recommended Solutions** ✅
Step-by-step solutions to fix the problem

**Example Solution:**
```
1. Verify Database Server Status
   Check if database service is running and accessible

2. Check Network Connectivity
   Ensure network connection between application and database

3. Validate Credentials
   Verify database username and password are correct
```

---

## 🔍 Pattern Detection Examples

### FixWise can detect these common issues:

#### **Database Issues** 🗄️
**Keywords detected:** database, connection, sql, mysql, postgres

**Example action:** Check database server is running

#### **Authentication/Authorization** 🔐
**Keywords detected:** auth, token, jwt, unauthorized, 401, 403

**Example action:** Refresh authentication token

#### **Timeout Issues** ⏱️
**Keywords detected:** timeout, slow, latency, deadline

**Example action:** Optimize database queries

#### **Memory Issues** 💾
**Keywords detected:** memory, oom, heap, allocation

**Example action:** Increase heap size

---

## 🆘 Troubleshooting

### Problem 1: "Blank Screen" or "Cannot Connect"
**Causes:**
- Python not installed
- Flask not installed
- Port 5000 already in use

**Solutions:**
```bash
# Step 1: Check Python is installed
python --version

# Step 2: Reinstall Flask
pip install flask --upgrade

# Step 3: Use different port
python app.py --port 5001
```

Then visit: `http://127.0.0.1:5001`

---

### Problem 2: "ModuleNotFoundError" or "No module named 'flask'"
**Cause:** Dependencies not installed

**Solution:**
```bash
pip install -r requirements.txt
```

If that doesn't work:
```bash
pip install flask flask-cors python-dotenv
```

---

### Problem 3: "File Upload Failed"
**Possible causes:**
- File is too large (over 100 MB)
- Wrong file format (must be .log or .txt)
- File is corrupted

**Solutions:**
- Make sure file ends with `.log` or `.txt`
- Check file size is under 100 MB
- Try with a different log file

---

### Problem 4: "Analysis Shows 'General System Issue'"
**Reason:** FixWise couldn't match the error to known patterns

**Solutions:**
- Try uploading a more specific log file
- Check if your log contains keywords like: error, database, timeout, auth
- Add more context to your log file

---

### Problem 5: Application Crashes or Freezes
**Solutions:**
```bash
# Stop the app
Press CTRL + C

# Clear cache
python -c "import shutil; shutil.rmtree('./__pycache__', ignore_errors=True)"

# Restart
python app.py
```

---

### Problem 6: "Port 5000 Already in Use"
**Cause:** Another application is using port 5000

**Solutions:**
```bash
# Option 1: Stop the other application

# Option 2: Use a different port
python app.py --port 8000

# Then visit: http://127.0.0.1:8000
```

---

## 📁 Project Structure

```
FixWise/
│
├── app.py                          # Main application file
│
├── requirements.txt                # List of dependencies
│
├── templates/                      # HTML templates
│   └── index.html                 # Main webpage
│
├── static/                         # CSS and JavaScript
│   ├── css/
│   │   └── style.css              # Styling
│   └── js/
│       └── script.js              # Functionality
│
├── uploads/                        # Where uploaded files are stored
│   └── (your log files)
│
└── README.md                       # This file

```

### File Explanations:

| File/Folder | Purpose |
|-------------|---------|
| `app.py` | The brain of FixWise - handles everything |
| `index.html` | The page you see in your browser |
| `style.css` | How the page looks (colors, layout) |
| `script.js` | What happens when you click buttons |
| `uploads/` | Where your log files are saved |
| `requirements.txt` | List of tools needed |

---

## ❓ FAQ (Frequently Asked Questions)

### Q1: Is my data safe?
**A:** Yes! Your log files are stored only on your computer. Nothing is sent to the cloud or external servers.

---

### Q2: Can I use FixWise without internet?
**A:** Yes! Once installed, FixWise works completely offline.

---

### Q3: What file formats are supported?
**A:** .log and .txt files. Both are plain text files. Other formats like .doc or .pdf won't work.

---

### Q4: What's the maximum file size?
**A:** 100 MB. This is about 5-10 million lines of text.

---

### Q5: Can FixWise analyze files from any application?
**A:** Yes! Any application that produces .log or .txt files.

**Common sources:**
- Web servers (Apache, Nginx)
- Databases (MySQL, PostgreSQL)
- Applications (Java, Python, Node.js)
- System logs
- Custom applications

---

### Q6: How accurate is the analysis?
**A:** About 80-95% accurate for common errors. Less accurate for very unusual or new types of errors.

The Confidence Score tells you how sure FixWise is.

---

### Q7: Can I delete my uploaded files?
**A:** Yes! Manually delete the `uploads/` folder contents or restart the application.

---

### Q8: How do I stop the application?
**A:** Press `CTRL + C` in the terminal/command prompt where you started it.

---

### Q9: Can multiple people use FixWise at the same time?
**A:** Yes! Just share the web address (http://127.0.0.1:5000) on your network.

Others on the same network can access it using:
```
http://[YOUR_IP]:5000
```

Find your IP:
- **Windows**: `ipconfig` in Command Prompt
- **Mac/Linux**: `ifconfig` in Terminal

---

### Q10: Why is my analysis showing "General System Issue"?
**A:** Your log doesn't contain typical error keywords. Try:
- Uploading a log with clear error messages
- Enabling debug/verbose logging in your application
- Checking if the log file is corrupted

---

### Q11: Can I customize the analysis?
**A:** Not in this version, but you can:
- Edit `static/js/script.js` to add custom patterns
- Add keywords to the `errorPatterns` object

---

### Q12: Is there a mobile app?
**A:** Not yet, but you can access FixWise from your phone's browser!

Just use:
```
http://[YOUR_COMPUTER_IP]:5000
```

---

## 🔧 For Technical Users

### Environment Variables
Create a `.env` file:
```
FLASK_ENV=production
UPLOAD_FOLDER=./uploads
MAX_FILE_SIZE=104857600
```

### Customization

#### Add Custom Error Patterns:
Edit `static/js/script.js` and add to `errorPatterns`:

```javascript
customError: {
    keywords: ['your', 'keywords', 'here'],
    rootCause: 'Your Custom Error',
    severity: 'critical',
    confidence: 85,
    errors: ['Error 1', 'Error 2'],
    solutions: [
        { title: 'Solution 1', description: 'Description' },
        { title: 'Solution 2', description: 'Description' }
    ]
}
```

#### Change Port Number:
```bash
python app.py --port 8000
```

#### Run in Production:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

---

## 📚 Requirements

### Core Requirements (in `requirements.txt`):
```
flask==3.0.0              # Web framework
flask-cors==4.0.0         # Cross-origin support
python-dotenv==1.0.0      # Environment variables
werkzeug==3.0.0          # Security utilities
```

### System Requirements:
- Python 3.8+
- 50 MB disk space
- 100 MB RAM (minimum)
- Modern web browser

---

## 🎓 Learning Resources

### Understanding Logs:
- What are logs? → [Read here](https://www.splunk.com/en_us/data-insider/what-are-logs.html)
- Log file formats → [Read here](https://en.wikipedia.org/wiki/Log_file)

### Understanding Errors:
- Common error types → Check FAQ section
- Error codes → [HTTP Status Codes](https://httpwg.org/specs/rfc7231.html#status.codes)

### Learning Flask:
- Flask official docs → [flask.palletsprojects.com](https://flask.palletsprojects.com/)

---

## 📞 Support

### Getting Help:

**1. Check Troubleshooting Section**
- Most common issues are listed with solutions

**2. Review the Logs**
- Check terminal/command prompt for error messages
- Google the error message

**3. Common Fixes**
```bash
# Clear cache
rm -rf __pycache__

# Reinstall dependencies
pip install -r requirements.txt --upgrade

# Use verbose mode to see what's happening
set FLASK_DEBUG=1  # Windows
export FLASK_DEBUG=1  # Mac/Linux
python app.py
```

---

## 📝 License

MIT License - You can use this freely!

---

## 🚀 Future Improvements

- Real-time log streaming
- Custom pattern creation UI
- Integration with monitoring services
- Advanced filtering options
- Export reports to PDF
- Multi-language support

---

## 🙏 Acknowledgments

Built with ❤️ using:
- Flask (Web framework)
- Font Awesome (Icons)
- Modern Web Technologies (HTML, CSS, JavaScript)

---

## 📞 Quick Support Checklist

Before asking for help, try:
- [ ] Python is installed? (`python --version`)
- [ ] Dependencies installed? (`pip install -r requirements.txt`)
- [ ] No other app using port 5000?
- [ ] Using .log or .txt file?
- [ ] File size under 100 MB?
- [ ] Browser is up to date?

---

## 💡 Tips for Best Results

1. **Use structured logs** - Logs with clear error messages work best
2. **Include stack traces** - Full error stack traces help analysis
3. **Recent logs** - Analyze logs from when the error occurred
4. **Multiple analyses** - If first analysis isn't helpful, try a different log section
5. **Cross-reference** - Use the "Log Content" tab to manually verify suggestions

---

## 🎯 Next Steps

1. **Install** - Follow the Installation Guide
2. **Try it** - Upload a log file and see results
3. **Learn** - Read the Understanding Results section
4. **Customize** - Add custom patterns for your needs
5. **Share** - Help others use FixWise!

---

**Happy debugging! 🐛→✨**

---

**Last Updated:** 2024
**Version:** 1.0.0
**Status:** Production Ready
